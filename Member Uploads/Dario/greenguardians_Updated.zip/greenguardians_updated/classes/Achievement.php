<?php
require_once __DIR__ . '/../config/config.php';

class Achievement {
    private $conn;
    private $table_name = "achievements";
    private $user_achievements_table = "user_achievements";

    public $id;
    public $name;
    public $description;
    public $badge_icon;
    public $points_required;
    public $missions_required;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAllAchievements() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE is_active = 1 ORDER BY points_required";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getUserAchievements($user_id) {
        $query = "SELECT a.*, ua.earned_at 
                  FROM " . $this->table_name . " a
                  INNER JOIN " . $this->user_achievements_table . " ua ON a.id = ua.achievement_id
                  WHERE ua.user_id = :user_id AND a.is_active = 1
                  ORDER BY ua.earned_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function checkAndAwardAchievements($user_id) {
        // Get user stats
        require_once 'User.php';
        $user = new User($this->conn);
        $user->getUserById($user_id);
        
        require_once 'Mission.php';
        $mission = new Mission($this->conn);
        $mission_stats = $mission->getUserMissionStats($user_id);
        
        $awarded_achievements = [];
        
        // Get all achievements
        $achievements = $this->getAllAchievements();
        
        foreach($achievements as $achievement) {
            // Check if user already has this achievement
            if(!$this->userHasAchievement($user_id, $achievement['id'])) {
                $should_award = false;
                
                // Check points requirement
                if($achievement['points_required'] > 0 && $user->eco_points >= $achievement['points_required']) {
                    $should_award = true;
                }
                
                // Check missions requirement
                if($achievement['missions_required'] > 0 && $mission_stats['completed_missions'] >= $achievement['missions_required']) {
                    $should_award = true;
                }
                
                // Special case for first mission achievement
                if($achievement['missions_required'] == 1 && $mission_stats['completed_missions'] >= 1) {
                    $should_award = true;
                }
                
                if($should_award) {
                    $this->awardAchievement($user_id, $achievement['id']);
                    $awarded_achievements[] = $achievement;
                }
            }
        }
        
        return $awarded_achievements;
    }

    private function userHasAchievement($user_id, $achievement_id) {
        $query = "SELECT id FROM " . $this->user_achievements_table . " 
                  WHERE user_id = :user_id AND achievement_id = :achievement_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->bindParam(":achievement_id", $achievement_id);
        $stmt->execute();
        
        return $stmt->rowCount() > 0;
    }

    private function awardAchievement($user_id, $achievement_id) {
        $query = "INSERT INTO " . $this->user_achievements_table . " 
                  SET user_id = :user_id, achievement_id = :achievement_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->bindParam(":achievement_id", $achievement_id);
        return $stmt->execute();
    }

    public function getAchievementProgress($user_id) {
        $total_achievements = count($this->getAllAchievements());
        $user_achievements = count($this->getUserAchievements($user_id));
        
        return [
            'total' => $total_achievements,
            'earned' => $user_achievements,
            'percentage' => $total_achievements > 0 ? round(($user_achievements / $total_achievements) * 100) : 0
        ];
    }

    // Admin functions
    public function createAchievement() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET name=:name, description=:description, badge_icon=:badge_icon, 
                      points_required=:points_required, missions_required=:missions_required";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":badge_icon", $this->badge_icon);
        $stmt->bindParam(":points_required", $this->points_required);
        $stmt->bindParam(":missions_required", $this->missions_required);

        return $stmt->execute();
    }

    public function updateAchievement() {
        $query = "UPDATE " . $this->table_name . " 
                  SET name=:name, description=:description, badge_icon=:badge_icon, 
                      points_required=:points_required, missions_required=:missions_required
                  WHERE id=:id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":badge_icon", $this->badge_icon);
        $stmt->bindParam(":points_required", $this->points_required);
        $stmt->bindParam(":missions_required", $this->missions_required);
        $stmt->bindParam(":id", $this->id);

        return $stmt->execute();
    }

    public function deleteAchievement($id) {
        $query = "UPDATE " . $this->table_name . " SET is_active = 0 WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }
}
?>

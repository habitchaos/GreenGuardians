<?php
require_once __DIR__ . '/../config/config.php';

class User {
    private $conn;
    private $table_name = "users";

    public $id;
    public $username;
    public $email;
    public $password;
    public $role;
    public $eco_points;
    public $eco_rank;
    public $avatar;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function register() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET username=:username, email=:email, password=:password";

        $stmt = $this->conn->prepare($query);

        // Sanitize inputs
        $this->username = sanitizeInput($this->username);
        $this->email = sanitizeInput($this->email);
        $this->password = password_hash($this->password, PASSWORD_DEFAULT);

        // Bind values
        $stmt->bindParam(":username", $this->username);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":password", $this->password);

        if($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    public function login() {
        $query = "SELECT id, username, email, password, role, eco_points, eco_rank, avatar 
                  FROM " . $this->table_name . " 
                  WHERE username = :username OR email = :username";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $this->username);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if(password_verify($this->password, $row['password'])) {
                $this->id = $row['id'];
                $this->username = $row['username'];
                $this->email = $row['email'];
                $this->role = $row['role'];
                $this->eco_points = $row['eco_points'];
                $this->eco_rank = $row['eco_rank'];
                $this->avatar = $row['avatar'];
                
                // Set session variables
                $_SESSION['user_id'] = $this->id;
                $_SESSION['username'] = $this->username;
                $_SESSION['user_role'] = $this->role;
                $_SESSION['eco_points'] = $this->eco_points;
                
                return true;
            }
        }
        return false;
    }

    public function getUserById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->id = $row['id'];
            $this->username = $row['username'];
            $this->email = $row['email'];
            $this->role = $row['role'];
            $this->eco_points = $row['eco_points'];
            $this->eco_rank = $row['eco_rank'];
            $this->avatar = $row['avatar'];
            return true;
        }
        return false;
    }

    public function updateEcoPoints($points) {
        $query = "UPDATE " . $this->table_name . " 
                  SET eco_points = eco_points + :points, eco_rank = :rank 
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);
        
        // Calculate new rank based on points
        $new_total = $this->eco_points + $points;
        $rank = $this->calculateEcoRank($new_total);

        $stmt->bindParam(":points", $points);
        $stmt->bindParam(":rank", $rank);
        $stmt->bindParam(":id", $this->id);

        if($stmt->execute()) {
            $this->eco_points = $new_total;
            $this->eco_rank = $rank;
            $_SESSION['eco_points'] = $this->eco_points;
            return true;
        }
        return false;
    }

    private function calculateEcoRank($points) {
        if($points >= 5000) return "Eco-Legend";
        if($points >= 2500) return "Climate Champion";
        if($points >= 1000) return "Planet Protector";
        if($points >= 500) return "Green Guardian";
        if($points >= 200) return "Eco-Warrior";
        return "Eco-Newbie";
    }

    public function getLeaderboard($limit = 10) {
        $query = "SELECT username, eco_points, eco_rank, avatar 
                  FROM " . $this->table_name . " 
                  WHERE role = 'user' 
                  ORDER BY eco_points DESC 
                  LIMIT :limit";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":limit", $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function emailExists() {
        $query = "SELECT id FROM " . $this->table_name . " WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":email", $this->email);
        $stmt->execute();
        
        return $stmt->rowCount() > 0;
    }

    public function usernameExists() {
        $query = "SELECT id FROM " . $this->table_name . " WHERE username = :username";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $this->username);
        $stmt->execute();
        
        return $stmt->rowCount() > 0;
    }
}
?>

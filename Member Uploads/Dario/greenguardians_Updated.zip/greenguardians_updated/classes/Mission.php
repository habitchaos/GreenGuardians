<?php
require_once __DIR__ . '/../config/config.php';

class Mission {
    private $conn;
    private $table_name = "missions";
    private $user_missions_table = "user_missions";

    public $id;
    public $title;
    public $description;
    public $difficulty;
    public $points_reward;
    public $sdg_goal;
    public $eco_fact;
    public $is_active;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAllMissions() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE is_active = 1 ORDER BY difficulty, id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getMissionById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id AND is_active = 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->id = $row['id'];
            $this->title = $row['title'];
            $this->description = $row['description'];
            $this->difficulty = $row['difficulty'];
            $this->points_reward = $row['points_reward'];
            $this->sdg_goal = $row['sdg_goal'];
            $this->eco_fact = $row['eco_fact'];
            return true;
        }
        return false;
    }

    public function getUserMissions($user_id) {
        $query = "SELECT m.*, um.status, um.score, um.completed_at 
                  FROM " . $this->table_name . " m
                  LEFT JOIN " . $this->user_missions_table . " um ON m.id = um.mission_id AND um.user_id = :user_id
                  WHERE m.is_active = 1
                  ORDER BY m.difficulty, m.id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function startMission($user_id, $mission_id) {
        // Check if mission already exists for user
        $check_query = "SELECT id FROM " . $this->user_missions_table . " 
                        WHERE user_id = :user_id AND mission_id = :mission_id";
        $check_stmt = $this->conn->prepare($check_query);
        $check_stmt->bindParam(":user_id", $user_id);
        $check_stmt->bindParam(":mission_id", $mission_id);
        $check_stmt->execute();

        if($check_stmt->rowCount() == 0) {
            // Insert new user mission
            $query = "INSERT INTO " . $this->user_missions_table . " 
                      SET user_id = :user_id, mission_id = :mission_id, status = 'in_progress'";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":user_id", $user_id);
            $stmt->bindParam(":mission_id", $mission_id);
            return $stmt->execute();
        } else {
            // Update existing mission to in_progress
            $query = "UPDATE " . $this->user_missions_table . " 
                      SET status = 'in_progress' 
                      WHERE user_id = :user_id AND mission_id = :mission_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":user_id", $user_id);
            $stmt->bindParam(":mission_id", $mission_id);
            return $stmt->execute();
        }
    }

    public function completeMission($user_id, $mission_id, $score = 100) {
        // Update mission status
        $query = "INSERT INTO " . $this->user_missions_table . " 
                  (user_id, mission_id, status, score, completed_at) 
                  VALUES (:user_id, :mission_id, 'completed', :score, NOW())
                  ON DUPLICATE KEY UPDATE 
                  status = 'completed', score = :score, completed_at = NOW()";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->bindParam(":mission_id", $mission_id);
        $stmt->bindParam(":score", $score);
        
        if($stmt->execute()) {
            // Get mission points
            $this->getMissionById($mission_id);
            $points = $this->points_reward;
            
            // Update user eco points
            require_once 'User.php';
            $user = new User($this->conn);
            $user->getUserById($user_id);
            $user->updateEcoPoints($points);
            
            // Check for achievements
            $this->checkAchievements($user_id);
            
            return $points;
        }
        return false;
    }

    public function getUserMissionStats($user_id) {
        $query = "SELECT 
                    COUNT(*) as total_missions,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_missions,
                    SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_missions,
                    AVG(CASE WHEN status = 'completed' THEN score ELSE NULL END) as avg_score
                  FROM " . $this->user_missions_table . " 
                  WHERE user_id = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    private function checkAchievements($user_id) {
        require_once 'Achievement.php';
        $achievement = new Achievement($this->conn);
        $achievement->checkAndAwardAchievements($user_id);
    }

    public function getMissionProgress($user_id, $mission_id) {
        $query = "SELECT status, score FROM " . $this->user_missions_table . " 
                  WHERE user_id = :user_id AND mission_id = :mission_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->bindParam(":mission_id", $mission_id);
        $stmt->execute();
        
        if($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return ['status' => 'not_started', 'score' => 0];
    }

    // Admin functions
    public function createMission() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET title=:title, description=:description, difficulty=:difficulty, 
                      points_reward=:points_reward, sdg_goal=:sdg_goal, eco_fact=:eco_fact";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":difficulty", $this->difficulty);
        $stmt->bindParam(":points_reward", $this->points_reward);
        $stmt->bindParam(":sdg_goal", $this->sdg_goal);
        $stmt->bindParam(":eco_fact", $this->eco_fact);

        return $stmt->execute();
    }

    public function updateMission() {
        $query = "UPDATE " . $this->table_name . " 
                  SET title=:title, description=:description, difficulty=:difficulty, 
                      points_reward=:points_reward, sdg_goal=:sdg_goal, eco_fact=:eco_fact
                  WHERE id=:id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":difficulty", $this->difficulty);
        $stmt->bindParam(":points_reward", $this->points_reward);
        $stmt->bindParam(":sdg_goal", $this->sdg_goal);
        $stmt->bindParam(":eco_fact", $this->eco_fact);
        $stmt->bindParam(":id", $this->id);

        return $stmt->execute();
    }

    public function deleteMission($id) {
        $query = "UPDATE " . $this->table_name . " SET is_active = 0 WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }
}
?>

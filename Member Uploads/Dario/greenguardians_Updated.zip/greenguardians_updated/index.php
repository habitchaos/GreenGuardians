<?php
require_once __DIR__ . '/config/config.php';

// Check if user is logged in and redirect to dashboard
if(isLoggedIn()) {
    redirect('dashboard/');
}

// Get some basic stats (without requiring database connection for homepage)
$total_missions = 5; // Static for homepage display
$total_users = "100+"; // Static for homepage display
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - Gamified Environmental Action</title>
    <meta name="description" content="Join GreenGuardians and become an Eco-Warrior! Complete environmental missions, earn eco-points, and help save our planet through engaging gameplay.">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-eco navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-leaf" style="font-size: 2.5rem;"></i>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="developers.php">Developers</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="btn btn-outline-light me-2" href="auth/login.php">
                            <i class="fas fa-sign-in-alt me-1"></i>Sign In
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-light" href="auth/register.php">
                            <i class="fas fa-user-plus me-1"></i>Sign Up
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main>
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h1 class="hero-title">Become an Eco-Warrior</h1>
                    <p class="hero-subtitle">Join the gamified revolution to save our planet! Complete environmental missions, earn eco-points, and make a real difference.</p>

                    <div class="mt-4">
                        <a href="auth/register.php" class="btn btn-light btn-lg shadow-lg hero-btn" style="background: white; color: #28a745; font-weight: bold; border: 2px solid white; opacity: 1 !important; visibility: visible !important; display: inline-block !important;">
                            <i class="fas fa-rocket me-2"></i>Get Started
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center mb-5">
                    <h2 class="display-5 fw-bold text-success">About GreenGuardians</h2>
                    <p class="lead text-muted">Transforming environmental education through interactive gaming</p>
                </div>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="eco-card p-5">
                        <!-- Main Description -->
                        <div class="text-center mb-5">
                            <div class="mb-4">
                                <i class="fas fa-seedling text-success" style="font-size: 4rem;"></i>
                            </div>
                            <h3 class="text-success mb-4">Empowering Tomorrow's Environmental Leaders</h3>
                            <p class="lead text-muted mb-4">
                                GreenGuardians is an innovative platform that combines gaming with environmental education. 
                                We believe that learning about sustainability should be engaging, interactive, and fun. 
                                Through our gamified missions and challenges, users develop real-world environmental awareness 
                                while earning rewards and building lasting eco-friendly habits.
                            </p>
                        </div>

                        <!-- Key Features Grid -->
                        <div class="row g-4 mb-5">
                            <div class="col-md-6">
                                <div class="d-flex align-items-start">
                                    <div class="flex-shrink-0">
                                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
                                            <i class="fas fa-graduation-cap" style="font-size: 1.5rem;"></i>
                                        </div>
                                    </div>
                                    <div class="ms-3">
                                        <h5 class="text-success mb-2">Educational Excellence</h5>
                                        <p class="text-muted mb-0">Science-backed content aligned with SDG 13 and 15, making complex environmental concepts accessible and engaging.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="d-flex align-items-start">
                                    <div class="flex-shrink-0">
                                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
                                            <i class="fas fa-users" style="font-size: 1.5rem;"></i>
                                        </div>
                                    </div>
                                    <div class="ms-3">
                                        <h5 class="text-success mb-2">Community Impact</h5>
                                        <p class="text-muted mb-0">Connect with like-minded eco-warriors, share achievements, and participate in collaborative environmental initiatives that create real change.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="d-flex align-items-start">
                                    <div class="flex-shrink-0">
                                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
                                            <i class="fas fa-trophy" style="font-size: 1.5rem;"></i>
                                        </div>
                                    </div>
                                    <div class="ms-3">
                                        <h5 class="text-success mb-2">Rewarding Progress</h5>
                                        <p class="text-muted mb-0">Earn eco-points, unlock achievements, and climb leaderboards as you complete missions and demonstrate your environmental knowledge.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="d-flex align-items-start">
                                    <div class="flex-shrink-0">
                                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
                                            <i class="fas fa-mobile-alt" style="font-size: 1.5rem;"></i>
                                        </div>
                                    </div>
                                    <div class="ms-3">
                                        <h5 class="text-success mb-2">Accessible Learning</h5>
                                        <p class="text-muted mb-0">Responsive design ensures seamless learning experiences across all devices, making environmental education available anytime, anywhere.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><i class="fas fa-leaf me-2"></i><?php echo SITE_NAME; ?></h5>
                    <p class="text-muted">Gamifying environmental action for a sustainable future.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="text-muted mb-1">
                        Supporting UN SDG 13 (Climate Action) & SDG 15 (Life on Land)
                    </p>
                    <p class="text-muted mb-1">
                        &copy; <?php echo date('Y'); ?> GreenGuardians. Built with 💚 for our planet.
                    </p>
                    <small class="text-muted">
                        Developed by GreenGuardians Team | Making environmental education engaging
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>

// GreenGuardians Main JavaScript File

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeAnimations();
    initializeTooltips();
    initializeProgressBars();
    initializeNotifications();
    initializeScrollAnimations();
    initializeStickyNavbar();
    initializeResponsiveFeatures();
    initializeFormValidation();
});

// Animation initialization
function initializeAnimations() {
    // Initial hero animations - only for button, not header text
    const heroButton = document.querySelector('.hero-btn');
    const heroButtonContainer = document.querySelector('.hero-section .mt-4');
    
    // Ensure hero button is immediately visible
    if (heroButtonContainer) {
        heroButtonContainer.style.opacity = '1';
        heroButtonContainer.style.transform = 'translateY(0)';
        heroButtonContainer.classList.add('animate');
    }
    
    if (heroButton) {
        heroButton.style.opacity = '1';
        heroButton.style.transform = 'translateY(0)';
        heroButton.style.visibility = 'visible';
        heroButton.style.display = 'inline-block';
    }

    // Pulse animation for important elements
    const pulseElements = document.querySelectorAll('.pulse');
    pulseElements.forEach(element => {
        element.addEventListener('mouseenter', function() {
            this.style.animation = 'pulse 0.5s ease-in-out';
        });
        
        element.addEventListener('animationend', function() {
            this.style.animation = '';
        });
    });
}

// Scroll Animations
function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
                
                // Handle staggered animations for children
                const children = entry.target.querySelectorAll('.animate-child');
                children.forEach((child, index) => {
                    setTimeout(() => {
                        child.classList.add('animate');
                    }, index * 150);
                });
            }
        });
    }, observerOptions);

    // Add animations to different sections
    addScrollAnimations(observer);
}

function addScrollAnimations(observer) {
    // About section
    const aboutCards = document.querySelectorAll('#about .eco-card');
    aboutCards.forEach((card, index) => {
        if (index % 2 === 0) {
            card.classList.add('slide-in-left');
        } else {
            card.classList.add('slide-in-right');
        }
        observer.observe(card);
    });

    // Features section
    const featureCards = document.querySelectorAll('#features .eco-card');
    featureCards.forEach((card, index) => {
        card.classList.add('fade-in-up', `animate-delay-${index + 1}`);
        observer.observe(card);
    });

    // Developer section
    const developerSection = document.querySelector('#developer');
    if (developerSection) {
        developerSection.classList.add('fade-in-up');
        observer.observe(developerSection);
    }

    // Project stats
    const projectStats = document.querySelectorAll('#developer .stat-item');
    projectStats.forEach((stat, index) => {
        stat.classList.add('scale-in', `animate-delay-${index + 1}`);
        observer.observe(stat);
    });

}

// Initialize Bootstrap tooltips
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Animate progress bars
function initializeProgressBars() {
    const progressBars = document.querySelectorAll('.progress-bar');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const progressBar = entry.target;
                const width = progressBar.style.width;
                progressBar.style.width = '0%';
                
                setTimeout(() => {
                    progressBar.style.transition = 'width 1s ease-in-out';
                    progressBar.style.width = width;
                }, 100);
                
                observer.unobserve(progressBar);
            }
        });
    });
    
    progressBars.forEach(bar => observer.observe(bar));
}

// Notification system
function initializeNotifications() {
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
}

// Eco-points counter animation
function animateEcoPoints(element, targetValue, duration = 1000) {
    const startValue = 0;
    const increment = targetValue / (duration / 16);
    let currentValue = startValue;
    
    const timer = setInterval(() => {
        currentValue += increment;
        if (currentValue >= targetValue) {
            currentValue = targetValue;
            clearInterval(timer);
        }
        element.textContent = Math.floor(currentValue).toLocaleString();
    }, 16);
}

// Mission completion celebration
function celebrateMissionCompletion(points) {
    // Create celebration modal
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body text-center p-5">
                    <div class="celebration-animation mb-4">
                        <i class="fas fa-trophy text-warning fa-4x pulse"></i>
                    </div>
                    <h3 class="text-success mb-3">Mission Accomplished!</h3>
                    <p class="text-muted mb-4">Congratulations! You've earned <strong class="text-success">${points} eco-points</strong>!</p>
                    <div class="confetti-container">
                        <div class="confetti"></div>
                        <div class="confetti"></div>
                        <div class="confetti"></div>
                        <div class="confetti"></div>
                        <div class="confetti"></div>
                    </div>
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">
                        <i class="fas fa-check me-2"></i>Continue
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    
    // Remove modal after hiding
    modal.addEventListener('hidden.bs.modal', () => {
        document.body.removeChild(modal);
    });
    
    // Add confetti CSS
    if (!document.getElementById('confetti-styles')) {
        const style = document.createElement('style');
        style.id = 'confetti-styles';
        style.textContent = `
            .confetti-container {
                position: relative;
                height: 50px;
                overflow: hidden;
            }
            
            .confetti {
                position: absolute;
                width: 10px;
                height: 10px;
                background: linear-gradient(45deg, #ff6b6b, #4ecdc4, #45b7d1, #96ceb4, #feca57);
                animation: confetti-fall 3s linear infinite;
            }
            
            .confetti:nth-child(1) { left: 10%; animation-delay: 0s; }
            .confetti:nth-child(2) { left: 30%; animation-delay: 0.5s; }
            .confetti:nth-child(3) { left: 50%; animation-delay: 1s; }
            .confetti:nth-child(4) { left: 70%; animation-delay: 1.5s; }
            .confetti:nth-child(5) { left: 90%; animation-delay: 2s; }
            
            @keyframes confetti-fall {
                0% {
                    transform: translateY(-100px) rotate(0deg);
                    opacity: 1;
                }
                100% {
                    transform: translateY(100px) rotate(720deg);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
}

// Achievement unlock notification
function showAchievementUnlock(achievement) {
    const notification = document.createElement('div');
    notification.className = 'achievement-notification';
    notification.innerHTML = `
        <div class="achievement-content">
            <div class="achievement-icon">
                <i class="fas fa-medal text-warning fa-2x"></i>
            </div>
            <div class="achievement-text">
                <h6 class="mb-1">Achievement Unlocked!</h6>
                <small>${achievement.name}</small>
            </div>
        </div>
    `;
    
    // Add styles if not exists
    if (!document.getElementById('achievement-styles')) {
        const style = document.createElement('style');
        style.id = 'achievement-styles';
        style.textContent = `
            .achievement-notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
                color: white;
                padding: 1rem;
                border-radius: 10px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
                z-index: 9999;
                transform: translateX(400px);
                transition: transform 0.5s ease;
            }
            
            .achievement-notification.show {
                transform: translateX(0);
            }
            
            .achievement-content {
                display: flex;
                align-items: center;
            }
            
            .achievement-icon {
                margin-right: 1rem;
            }
            
            .achievement-text h6 {
                margin: 0;
                font-weight: bold;
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Hide and remove after 4 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                document.body.removeChild(notification);
            }
        }, 500);
    }, 4000);
}

// Form validation helpers
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePassword(password) {
    return password.length >= 6;
}

function validateUsername(username) {
    return username.length >= 3 && /^[a-zA-Z0-9_]+$/.test(username);
}

// Real-time form validation
function initializeFormValidation() {
    const forms = document.querySelectorAll('form[data-validate="true"]');
    
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input[required]');
        
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                if (this.classList.contains('is-invalid')) {
                    validateField(this);
                }
            });
        });
        
        form.addEventListener('submit', function(e) {
            let isValid = true;
            
            inputs.forEach(input => {
                if (!validateField(input)) {
                    isValid = false;
                }
            });
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    });
}

function validateField(field) {
    const value = field.value.trim();
    const type = field.type;
    const name = field.name;
    let isValid = true;
    let message = '';
    
    // Remove existing feedback
    const existingFeedback = field.parentNode.querySelector('.invalid-feedback');
    if (existingFeedback) {
        existingFeedback.remove();
    }
    
    field.classList.remove('is-valid', 'is-invalid');
    
    if (field.hasAttribute('required') && !value) {
        isValid = false;
        message = 'This field is required.';
    } else if (value) {
        switch (type) {
            case 'email':
                if (!validateEmail(value)) {
                    isValid = false;
                    message = 'Please enter a valid email address.';
                }
                break;
            case 'password':
                if (!validatePassword(value)) {
                    isValid = false;
                    message = 'Password must be at least 6 characters long.';
                }
                break;
            default:
                if (name === 'username' && !validateUsername(value)) {
                    isValid = false;
                    message = 'Username must be at least 3 characters and contain only letters, numbers, and underscores.';
                }
        }
    }
    
    if (isValid) {
        field.classList.add('is-valid');
    } else {
        field.classList.add('is-invalid');
        const feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        feedback.textContent = message;
        field.parentNode.appendChild(feedback);
    }
    
    return isValid;
}

// Loading states
function showLoading(element, text = 'Loading...') {
    const originalContent = element.innerHTML;
    element.setAttribute('data-original-content', originalContent);
    element.disabled = true;
    element.innerHTML = `
        <span class="spinner-border spinner-border-sm me-2" role="status"></span>
        ${text}
    `;
}

function hideLoading(element) {
    const originalContent = element.getAttribute('data-original-content');
    if (originalContent) {
        element.innerHTML = originalContent;
        element.disabled = false;
        element.removeAttribute('data-original-content');
    }
}

// Smooth scrolling for anchor links
function initializeSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                e.preventDefault();
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Initialize smooth scrolling
initializeSmoothScrolling();

// Eco-rank color helper
function getEcoRankColor(rank) {
    const colors = {
        'eco-newbie': '#6c757d',
        'eco-warrior': '#28a745',
        'green-guardian': '#17a2b8',
        'planet-protector': '#28a745',
        'climate-champion': '#ffc107',
        'eco-legend': '#fd7e14'
    };
    
    return colors[rank.toLowerCase().replace(/[^a-z]/g, '-')] || '#6c757d';
}

// Developer Slider Functionality
let currentSlide = 1;
const totalSlides = 4;

function showSlide(n, direction = 'next') {
    const slides = document.querySelectorAll('.developer-slide');
    const dots = document.querySelectorAll('.dot');
    
    if (n > totalSlides) currentSlide = 1;
    if (n < 1) currentSlide = totalSlides;
    
    // Find current active slide
    const currentActiveSlide = document.querySelector('.developer-slide.active');
    const targetSlide = slides[currentSlide - 1];
    
    if (currentActiveSlide && targetSlide && currentActiveSlide !== targetSlide) {
        // Add fade-out class to current slide
        currentActiveSlide.classList.add('fade-out');
        
        // After fade-out completes, switch to new slide
        setTimeout(() => {
            // Remove active and fade-out from all slides
            slides.forEach(slide => {
                slide.classList.remove('active', 'fade-out', 'fade-in');
            });
            
            // Add active and fade-in to target slide
            targetSlide.classList.add('active', 'fade-in');
            
            // Clean up fade-in class after animation
            setTimeout(() => {
                targetSlide.classList.remove('fade-in');
            }, 600);
            
        }, 300); // Wait for fade-out to complete
    } else if (targetSlide) {
        // First load or same slide - no animation needed
        slides.forEach(slide => {
            slide.classList.remove('active', 'fade-out', 'fade-in');
        });
        targetSlide.classList.add('active');
    }
    
    // Update dots immediately
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentSlide - 1);
    });
}

function nextDeveloper() {
    currentSlide++;
    showSlide(currentSlide, 'next');
}

function prevDeveloper() {
    currentSlide--;
    showSlide(currentSlide, 'prev');
}

function currentDeveloper(n) {
    currentSlide = n;
    showSlide(currentSlide);
}

// Auto-slide functionality (optional)
function startAutoSlide() {
    setInterval(() => {
        nextDeveloper();
    }, 5000); // Change slide every 5 seconds
}

// Initialize slider when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the first slide for developer section
    showSlide(currentSlide);
    
    // Initialize the first slide for about section
    showAboutSlide(currentAboutSlide);
    
    // Uncomment the line below to enable auto-sliding
    // startAutoSlide();
    
    // Add keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowLeft') {
            prevDeveloper();
        } else if (e.key === 'ArrowRight') {
            nextDeveloper();
        }
    });
});

// Export functions for global use
window.GreenGuardians = {
    animateEcoPoints,
    celebrateMissionCompletion,
    showAchievementUnlock,
    showLoading,
    hideLoading,
    validateEmail,
    validatePassword,
    validateUsername,
    getEcoRankColor,
    isMobile,
    isTablet,
    isDesktop,
    getCurrentBreakpoint,
    showResponsiveNotification
};

// Make slider functions globally available
window.nextDeveloper = nextDeveloper;
window.prevDeveloper = prevDeveloper;
window.currentDeveloper = currentDeveloper;

// About Slider Functionality
let currentAboutSlide = 1;
const totalAboutSlides = 3;

function showAboutSlide(n, direction = 'next') {
    const slides = document.querySelectorAll('.about-slide');
    const dots = document.querySelectorAll('.about-slider-container .dot');
    
    if (n > totalAboutSlides) currentAboutSlide = 1;
    if (n < 1) currentAboutSlide = totalAboutSlides;
    
    // Remove active class from all slides
    slides.forEach(slide => {
        slide.classList.remove('active');
    });
    
    // Add active class to target slide
    const targetSlide = slides[currentAboutSlide - 1];
    if (targetSlide) {
        targetSlide.classList.add('active');
    }
    
    // Update dots
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentAboutSlide - 1);
    });
}

function nextAbout() {
    currentAboutSlide++;
    showAboutSlide(currentAboutSlide, 'next');
}

function prevAbout() {
    currentAboutSlide--;
    showAboutSlide(currentAboutSlide, 'prev');
}

function currentAbout(n) {
    currentAboutSlide = n;
    showAboutSlide(currentAboutSlide);
}

// Make About slider functions globally available
window.nextAbout = nextAbout;
window.prevAbout = prevAbout;
window.currentAbout = currentAbout;

// Sticky Navbar functionality
function initializeStickyNavbar() {
    const navbar = document.querySelector('.navbar-eco');
    
    if (!navbar) return;
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
}

// Responsive Features Initialization
function initializeResponsiveFeatures() {
    // Handle responsive navigation
    initializeResponsiveNavigation();
    
    // Handle responsive images
    initializeResponsiveImages();
    
    // Handle responsive tables
    initializeResponsiveTables();
    
    // Handle touch gestures for mobile
    initializeTouchGestures();
    
    // Handle viewport changes
    initializeViewportHandler();
    
    // Handle responsive modals
    initializeResponsiveModals();
}

// Responsive Navigation
function initializeResponsiveNavigation() {
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (!navbarToggler || !navbarCollapse) return;
    
    // Close mobile menu when clicking on links
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth < 992) {
                const bsCollapse = new bootstrap.Collapse(navbarCollapse, {
                    toggle: false
                });
                bsCollapse.hide();
            }
        });
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', function(e) {
        if (window.innerWidth < 992 && 
            !navbarToggler.contains(e.target) && 
            !navbarCollapse.contains(e.target) &&
            navbarCollapse.classList.contains('show')) {
            const bsCollapse = new bootstrap.Collapse(navbarCollapse, {
                toggle: false
            });
            bsCollapse.hide();
        }
    });
}

// Responsive Images
function initializeResponsiveImages() {
    const images = document.querySelectorAll('img');
    
    images.forEach(img => {
        // Add responsive classes if not present
        if (!img.classList.contains('img-fluid')) {
            img.classList.add('img-fluid');
        }
        
        // Handle image loading errors
        img.addEventListener('error', function() {
            this.style.display = 'none';
        });
    });
}

// Responsive Tables
function initializeResponsiveTables() {
    const tables = document.querySelectorAll('table:not(.table-responsive table)');
    
    tables.forEach(table => {
        // Wrap tables in responsive container
        const wrapper = document.createElement('div');
        wrapper.className = 'table-responsive';
        table.parentNode.insertBefore(wrapper, table);
        wrapper.appendChild(table);
        
        // Add Bootstrap table classes
        if (!table.classList.contains('table')) {
            table.classList.add('table');
        }
    });
}

// Touch Gestures for Mobile
function initializeTouchGestures() {
    if (!('ontouchstart' in window)) return;
    
    // Swipe gestures for developer slider
    const developerSliderContainer = document.querySelector('.developer-slider-container');
    if (developerSliderContainer) {
        let startX = 0;
        let startY = 0;
        
        developerSliderContainer.addEventListener('touchstart', function(e) {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        }, { passive: true });
        
        developerSliderContainer.addEventListener('touchend', function(e) {
            if (!startX || !startY) return;
            
            const endX = e.changedTouches[0].clientX;
            const endY = e.changedTouches[0].clientY;
            
            const diffX = startX - endX;
            const diffY = startY - endY;
            
            // Only trigger if horizontal swipe is more significant than vertical
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                if (diffX > 0) {
                    // Swipe left - next slide
                    nextDeveloper();
                } else {
                    // Swipe right - previous slide
                    prevDeveloper();
                }
            }
            
            startX = 0;
            startY = 0;
        }, { passive: true });
    }
    
    // Swipe gestures for about slider
    const aboutSliderContainer = document.querySelector('.about-slider-container');
    if (aboutSliderContainer) {
        let startX = 0;
        let startY = 0;
        
        aboutSliderContainer.addEventListener('touchstart', function(e) {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        }, { passive: true });
        
        aboutSliderContainer.addEventListener('touchend', function(e) {
            if (!startX || !startY) return;
            
            const endX = e.changedTouches[0].clientX;
            const endY = e.changedTouches[0].clientY;
            
            const diffX = startX - endX;
            const diffY = startY - endY;
            
            // Only trigger if horizontal swipe is more significant than vertical
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                if (diffX > 0) {
                    // Swipe left - next slide
                    nextAbout();
                } else {
                    // Swipe right - previous slide
                    prevAbout();
                }
            }
            
            startX = 0;
            startY = 0;
        }, { passive: true });
    }
}

// Viewport Handler
function initializeViewportHandler() {
    let resizeTimer;
    
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            handleViewportChange();
        }, 250);
    });
    
    // Handle orientation change
    window.addEventListener('orientationchange', function() {
        setTimeout(handleViewportChange, 500);
    });
}

function handleViewportChange() {
    // Recalculate animations
    const animatedElements = document.querySelectorAll('.animate');
    animatedElements.forEach(element => {
        element.classList.remove('animate');
        setTimeout(() => {
            element.classList.add('animate');
        }, 100);
    });
    
    // Adjust modal sizes
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (modal.classList.contains('show')) {
            const modalDialog = modal.querySelector('.modal-dialog');
            if (modalDialog && window.innerWidth < 576) {
                modalDialog.style.margin = '0.5rem';
            } else if (modalDialog) {
                modalDialog.style.margin = '';
            }
        }
    });
}

// Responsive Modals
function initializeResponsiveModals() {
    const modals = document.querySelectorAll('.modal');
    
    modals.forEach(modal => {
        modal.addEventListener('show.bs.modal', function() {
            if (window.innerWidth < 576) {
                const modalDialog = this.querySelector('.modal-dialog');
                if (modalDialog) {
                    modalDialog.style.margin = '0.5rem';
                }
            }
        });
    });
}

// Responsive Utility Functions
function isMobile() {
    return window.innerWidth < 768;
}

function isTablet() {
    return window.innerWidth >= 768 && window.innerWidth < 992;
}

function isDesktop() {
    return window.innerWidth >= 992;
}

function getCurrentBreakpoint() {
    if (window.innerWidth < 576) return 'xs';
    if (window.innerWidth < 768) return 'sm';
    if (window.innerWidth < 992) return 'md';
    if (window.innerWidth < 1200) return 'lg';
    if (window.innerWidth < 1400) return 'xl';
    return 'xxl';
}

// Enhanced Developer Slider for Mobile
function enhancedShowSlide(n, direction = 'next') {
    const slides = document.querySelectorAll('.developer-slide');
    const dots = document.querySelectorAll('.dot');
    
    if (n > totalSlides) currentSlide = 1;
    if (n < 1) currentSlide = totalSlides;
    
    // Add transition class based on direction
    slides.forEach((slide, index) => {
        slide.classList.remove('active', 'slide-in-left', 'slide-in-right');
        
        if (index === currentSlide - 1) {
            slide.classList.add('active');
            if (isMobile()) {
                slide.classList.add(direction === 'next' ? 'slide-in-left' : 'slide-in-right');
            }
        }
    });
    
    // Update dots
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentSlide - 1);
    });
}

// Enhanced notification positioning for mobile
function showResponsiveNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    
    if (isMobile()) {
        notification.style.cssText = `
            top: 10px;
            left: 10px;
            right: 10px;
            z-index: 9999;
            margin: 0;
        `;
    } else {
        notification.style.cssText = `
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
        `;
    }
    
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            const bsAlert = new bootstrap.Alert(notification);
            bsAlert.close();
        }
    }, 5000);
}

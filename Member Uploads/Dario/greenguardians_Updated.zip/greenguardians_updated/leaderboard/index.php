<?php
require_once '../config/config.php';
require_once '../classes/User.php';
require_once '../classes/Mission.php';

$database = new Database();
$db = $database->getConnection();

$user = new User($db);
$mission = new Mission($db);

// Get leaderboard data
$leaderboard = $user->getLeaderboard(50);
$current_user_position = 0;

// Find current user position if logged in
if(isLoggedIn()) {
    $current_user = new User($db);
    $current_user->getUserById($_SESSION['user_id']);
    
    foreach($leaderboard as $index => $leader) {
        if($leader['username'] === $current_user->username) {
            $current_user_position = $index + 1;
            break;
        }
    }
}

// Get some stats
$total_users = count($leaderboard);
$total_missions = count($mission->getAllMissions());
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-eco navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../">
                <i class="fas fa-leaf me-2"></i><?php echo SITE_NAME; ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if(isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../dashboard/">
                                <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../game/">
                                <i class="fas fa-gamepad me-1"></i>Play
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">
                            <i class="fas fa-trophy me-1"></i>Leaderboard
                        </a>
                    </li>
                    <?php if(isLoggedIn()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($current_user->username); ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../profile/"><i class="fas fa-user-edit me-2"></i>Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../auth/login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-outline-light ms-2" href="../auth/register.php">Join Now</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Header -->
    <div class="dashboard-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-2"><i class="fas fa-trophy me-2"></i>Global Leaderboard</h1>
                    <p class="mb-0 opacity-75">See who's leading the fight for our planet!</p>
                </div>
                <div class="col-md-4 text-md-end">
                    <?php if(isLoggedIn() && $current_user_position): ?>
                        <div class="text-white">
                            <div class="fs-4 fw-bold">#<?php echo $current_user_position; ?></div>
                            <small>Your Rank</small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-4">
        <!-- Stats Overview -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-users text-primary" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-primary mb-0"><?php echo number_format($total_users); ?></h3>
                    <small class="text-muted">Active Eco-Warriors</small>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-tasks text-success" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-success mb-0"><?php echo $total_missions; ?></h3>
                    <small class="text-muted">Environmental Missions</small>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-coins text-warning" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-warning mb-0"><?php echo !empty($leaderboard) ? number_format($leaderboard[0]['eco_points']) : '0'; ?></h3>
                    <small class="text-muted">Highest Score</small>
                </div>
            </div>
        </div>

        <!-- Leaderboard -->
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="eco-card p-4">
                    <h4 class="mb-4 text-center">
                        <i class="fas fa-crown text-warning me-2"></i>Top Eco-Warriors
                    </h4>
                    
                    <?php if(!empty($leaderboard)): ?>
                        <!-- Top 3 Podium -->
                        <?php if(count($leaderboard) >= 3): ?>
                        <div class="row mb-5">
                            <div class="col-12">
                                <div class="podium d-flex justify-content-center align-items-end">
                                    <!-- 2nd Place -->
                                    <div class="text-center me-4">
                                        <div class="podium-rank rank-2 mb-2">
                                            <i class="fas fa-medal fa-3x"></i>
                                        </div>
                                        <div class="eco-card p-3" style="min-height: 120px;">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($leaderboard[1]['username']); ?></h6>
                                            <small class="eco-rank rank-<?php echo strtolower(str_replace([' ', '-'], '-', $leaderboard[1]['eco_rank'])); ?>">
                                                <?php echo $leaderboard[1]['eco_rank']; ?>
                                            </small>
                                            <div class="mt-2">
                                                <span class="fw-bold text-success">
                                                    <i class="fas fa-coins me-1"></i><?php echo number_format($leaderboard[1]['eco_points']); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- 1st Place -->
                                    <div class="text-center me-4">
                                        <div class="podium-rank rank-1 mb-2">
                                            <i class="fas fa-crown fa-3x"></i>
                                        </div>
                                        <div class="eco-card p-3" style="min-height: 140px; border: 3px solid #ffd700;">
                                            <h5 class="mb-1 text-warning"><?php echo htmlspecialchars($leaderboard[0]['username']); ?></h5>
                                            <small class="eco-rank rank-<?php echo strtolower(str_replace([' ', '-'], '-', $leaderboard[0]['eco_rank'])); ?>">
                                                <?php echo $leaderboard[0]['eco_rank']; ?>
                                            </small>
                                            <div class="mt-2">
                                                <span class="fw-bold text-success fs-5">
                                                    <i class="fas fa-coins me-1"></i><?php echo number_format($leaderboard[0]['eco_points']); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- 3rd Place -->
                                    <div class="text-center">
                                        <div class="podium-rank rank-3 mb-2">
                                            <i class="fas fa-medal fa-3x"></i>
                                        </div>
                                        <div class="eco-card p-3" style="min-height: 100px;">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($leaderboard[2]['username']); ?></h6>
                                            <small class="eco-rank rank-<?php echo strtolower(str_replace([' ', '-'], '-', $leaderboard[2]['eco_rank'])); ?>">
                                                <?php echo $leaderboard[2]['eco_rank']; ?>
                                            </small>
                                            <div class="mt-2">
                                                <span class="fw-bold text-success">
                                                    <i class="fas fa-coins me-1"></i><?php echo number_format($leaderboard[2]['eco_points']); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Full Leaderboard -->
                        <div class="leaderboard-list">
                            <?php foreach($leaderboard as $index => $leader): ?>
                            <div class="leaderboard-item <?php echo isLoggedIn() && $leader['username'] === $current_user->username ? 'border border-success' : ''; ?>">
                                <div class="leaderboard-rank rank-<?php echo $index + 1; ?>">
                                    #<?php echo $index + 1; ?>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-0">
                                                <?php echo htmlspecialchars($leader['username']); ?>
                                                <?php if(isLoggedIn() && $leader['username'] === $current_user->username): ?>
                                                    <span class="badge bg-success ms-2">You</span>
                                                <?php endif; ?>
                                            </h6>
                                            <small class="eco-rank rank-<?php echo strtolower(str_replace([' ', '-'], '-', $leader['eco_rank'])); ?>">
                                                <?php echo $leader['eco_rank']; ?>
                                            </small>
                                        </div>
                                        <div class="text-end">
                                            <span class="fw-bold text-success">
                                                <i class="fas fa-coins me-1"></i><?php echo number_format($leader['eco_points']); ?>
                                            </span>
                                            <?php if($index < 3): ?>
                                                <div class="mt-1">
                                                    <?php if($index === 0): ?>
                                                        <i class="fas fa-crown text-warning"></i>
                                                    <?php else: ?>
                                                        <i class="fas fa-medal text-<?php echo $index === 1 ? 'secondary' : 'warning'; ?>"></i>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-users fa-3x text-muted mb-3"></i>
                            <h5>No Eco-Warriors Yet</h5>
                            <p class="text-muted">Be the first to join and start earning eco-points!</p>
                            <?php if(!isLoggedIn()): ?>
                                <a href="../auth/register.php" class="btn btn-success">
                                    <i class="fas fa-rocket me-2"></i>Join Now
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Call to Action -->
        <?php if(!isLoggedIn()): ?>
        <div class="row mt-4">
            <div class="col-12 text-center">
                <div class="eco-card p-4">
                    <h4 class="text-success mb-3">Ready to Join the Competition?</h4>
                    <p class="text-muted mb-4">Start your eco-warrior journey and climb the leaderboard!</p>
                    <a href="../auth/register.php" class="btn btn-success btn-lg me-3">
                        <i class="fas fa-user-plus me-2"></i>Create Account
                    </a>
                    <a href="../auth/login.php" class="btn btn-outline-success btn-lg">
                        <i class="fas fa-sign-in-alt me-2"></i>Login
                    </a>
                </div>
            </div>
        </div>
        <?php elseif($current_user_position === 0): ?>
        <div class="row mt-4">
            <div class="col-12 text-center">
                <div class="eco-card p-4">
                    <h4 class="text-success mb-3">Start Your Eco-Journey!</h4>
                    <p class="text-muted mb-4">Complete missions to earn eco-points and appear on the leaderboard!</p>
                    <a href="../game/" class="btn btn-success btn-lg">
                        <i class="fas fa-play me-2"></i>Start First Mission
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add animation to leaderboard items
        document.addEventListener('DOMContentLoaded', function() {
            const items = document.querySelectorAll('.leaderboard-item');
            items.forEach((item, index) => {
                item.style.animationDelay = `${index * 0.1}s`;
                item.classList.add('fade-in-up');
            });
        });
    </script>
</body>
</html>

<?php
require_once __DIR__ . '/../config/config.php';

// Destroy session and redirect to home
session_destroy();
redirect('../');
?>

<?php
require_once '../config/config.php';
require_once '../classes/User.php';
require_once '../classes/Mission.php';

// Check if user is logged in
if(!isLoggedIn()) {
    redirect('../auth/login.php');
}

// Get mission ID
$mission_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$mission_id) {
    redirect('./');
}

$database = new Database();
$db = $database->getConnection();

$user = new User($db);
$mission = new Mission($db);

// Get current user data
$user->getUserById($_SESSION['user_id']);

// Get mission data
if(!$mission->getMissionById($mission_id)) {
    redirect('./');
}

// Get mission progress
$progress = $mission->getMissionProgress($_SESSION['user_id'], $mission_id);

// Handle mission completion
if($_POST && isset($_POST['complete_mission'])) {
    if(verifyCSRFToken($_POST['csrf_token'])) {
        $score = isset($_POST['score']) ? (int)$_POST['score'] : 100;
        $points_earned = $mission->completeMission($_SESSION['user_id'], $mission_id, $score);
        
        if($points_earned) {
            $_SESSION['eco_points'] += $points_earned;
            $success_message = "Mission completed! You earned {$points_earned} eco-points!";
            $progress['status'] = 'completed';
            $progress['score'] = $score;
        }
    }
}

// Start mission if not started
if($progress['status'] === 'not_started') {
    $mission->startMission($_SESSION['user_id'], $mission_id);
    $progress['status'] = 'in_progress';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($mission->title); ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="game-container">
    <div class="container">
        <!-- Game Header -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center text-white">
                    <div>
                        <a href="./" class="btn btn-outline-light btn-sm me-3">
                            <i class="fas fa-arrow-left me-1"></i>Back to Missions
                        </a>
                        <span class="eco-rank rank-<?php echo strtolower(str_replace([' ', '-'], '-', $user->eco_rank)); ?>">
                            <?php echo $user->eco_rank; ?>
                        </span>
                    </div>
                    <div class="text-end">
                        <div class="mb-1">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($user->username); ?>
                        </div>
                        <div>
                            <i class="fas fa-coins me-1"></i><?php echo number_format($user->eco_points); ?> Points
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Game Board -->
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="game-board">
                    <!-- Mission Header -->
                    <div class="row mb-4">
                        <div class="col-md-8">
                            <div class="d-flex align-items-center mb-2">
                                <span class="sdg-badge me-2"><?php echo htmlspecialchars($mission->sdg_goal); ?></span>
                                <span class="badge bg-<?php echo $mission->difficulty == 'easy' ? 'success' : ($mission->difficulty == 'medium' ? 'warning' : 'danger'); ?>">
                                    <?php echo ucfirst($mission->difficulty); ?>
                                </span>
                            </div>
                            <h2 class="text-success mb-2"><?php echo htmlspecialchars($mission->title); ?></h2>
                            <p class="text-muted"><?php echo htmlspecialchars($mission->description); ?></p>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <div class="mb-2">
                                <span class="text-success fw-bold fs-4">
                                    <i class="fas fa-coins me-1"></i><?php echo $mission->points_reward; ?>
                                </span>
                                <small class="text-muted d-block">Eco-Points Reward</small>
                            </div>
                            <?php if($progress['status'] === 'completed'): ?>
                                <div class="badge bg-success fs-6">
                                    <i class="fas fa-check me-1"></i>Completed (<?php echo $progress['score']; ?>%)
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if(isset($success_message)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-trophy me-2"></i><?php echo $success_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php endif; ?>

                    <!-- Game Area -->
                    <div class="mini-game" id="gameArea">
                        <?php if($progress['status'] === 'completed'): ?>
                            <!-- Completed State -->
                            <div class="text-center">
                                <i class="fas fa-trophy text-warning fa-4x mb-3 pulse"></i>
                                <h3 class="text-success mb-3">Mission Accomplished!</h3>
                                <p class="text-muted mb-4">You've successfully completed this environmental mission and earned <?php echo $mission->points_reward; ?> eco-points!</p>
                                
                                <?php if($mission->eco_fact): ?>
                                <div class="eco-fact text-start">
                                    <h5><i class="fas fa-lightbulb me-2 text-warning"></i>Did You Know?</h5>
                                    <p><?php echo htmlspecialchars($mission->eco_fact); ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <div class="mt-4">
                                    <a href="./" class="btn btn-success me-2">
                                        <i class="fas fa-list me-1"></i>More Missions
                                    </a>
                                    <a href="../dashboard/" class="btn btn-outline-success">
                                        <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                                    </a>
                                </div>
                            </div>
                        <?php else: ?>
                            <!-- Active Game State -->
                            <div class="text-center">
                                <h3 class="mb-4">🌱 <?php echo htmlspecialchars($mission->title); ?></h3>
                                
                                <!-- Game Interface based on mission type -->
                                <?php if(strpos(strtolower($mission->title), 'tree') !== false): ?>
                                    <!-- Tree Planting Game -->
                                    <div id="treePlantingGame">
                                        <div class="mb-4">
                                            <h5>Plant trees to restore the forest!</h5>
                                            <p class="text-muted">Click on the empty spots to plant trees</p>
                                        </div>
                                        
                                        <div class="tree-grid mb-4">
                                            <div class="row g-2 justify-content-center">
                                                <?php for($i = 1; $i <= 12; $i++): ?>
                                                <div class="col-2">
                                                    <div class="tree-spot" data-spot="<?php echo $i; ?>" onclick="plantTree(this)">
                                                        <i class="fas fa-circle text-muted fa-2x"></i>
                                                    </div>
                                                </div>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <div class="progress-eco">
                                                <div class="progress-bar" id="treeProgress" style="width: 0%"></div>
                                            </div>
                                            <small class="text-muted">Trees planted: <span id="treesPlanted">0</span>/12</small>
                                        </div>
                                    </div>
                                    
                                <?php elseif(strpos(strtolower($mission->title), 'waste') !== false): ?>
                                    <!-- Waste Sorting Game -->
                                    <div id="wasteSortingGame">
                                        <div class="mb-4">
                                            <h5>Sort the waste into correct bins!</h5>
                                            <p class="text-muted">Drag items to the appropriate recycling bins</p>
                                        </div>
                                        
                                        <div class="waste-items mb-4">
                                            <div class="row justify-content-center">
                                                <div class="col-auto waste-item" data-type="plastic" onclick="sortWaste(this, 'plastic')">
                                                    <i class="fas fa-bottle-water fa-2x text-info"></i>
                                                    <small class="d-block">Plastic Bottle</small>
                                                </div>
                                                <div class="col-auto waste-item" data-type="paper" onclick="sortWaste(this, 'paper')">
                                                    <i class="fas fa-newspaper fa-2x text-warning"></i>
                                                    <small class="d-block">Paper</small>
                                                </div>
                                                <div class="col-auto waste-item" data-type="glass" onclick="sortWaste(this, 'glass')">
                                                    <i class="fas fa-wine-bottle fa-2x text-success"></i>
                                                    <small class="d-block">Glass Bottle</small>
                                                </div>
                                                <div class="col-auto waste-item" data-type="organic" onclick="sortWaste(this, 'organic')">
                                                    <i class="fas fa-apple-alt fa-2x text-danger"></i>
                                                    <small class="d-block">Food Waste</small>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="sorting-bins">
                                            <div class="row">
                                                <div class="col-3">
                                                    <div class="bin" data-bin="plastic">
                                                        <i class="fas fa-recycle text-info fa-2x"></i>
                                                        <small class="d-block">Plastic</small>
                                                    </div>
                                                </div>
                                                <div class="col-3">
                                                    <div class="bin" data-bin="paper">
                                                        <i class="fas fa-recycle text-warning fa-2x"></i>
                                                        <small class="d-block">Paper</small>
                                                    </div>
                                                </div>
                                                <div class="col-3">
                                                    <div class="bin" data-bin="glass">
                                                        <i class="fas fa-recycle text-success fa-2x"></i>
                                                        <small class="d-block">Glass</small>
                                                    </div>
                                                </div>
                                                <div class="col-3">
                                                    <div class="bin" data-bin="organic">
                                                        <i class="fas fa-seedling text-danger fa-2x"></i>
                                                        <small class="d-block">Organic</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-3">
                                            <div class="progress-eco">
                                                <div class="progress-bar" id="wasteProgress" style="width: 0%"></div>
                                            </div>
                                            <small class="text-muted">Items sorted: <span id="itemsSorted">0</span>/4</small>
                                        </div>
                                    </div>
                                    
                                <?php else: ?>
                                    <!-- Generic Environmental Challenge -->
                                    <div id="genericGame">
                                        <div class="mb-4">
                                            <h5>Complete the Environmental Challenge!</h5>
                                            <p class="text-muted">Answer questions and complete tasks to help the environment</p>
                                        </div>
                                        
                                        <div class="challenge-area">
                                            <div class="mb-4">
                                                <h6>Environmental Quiz</h6>
                                                <div class="quiz-question">
                                                    <p><strong>What percentage of the Earth's surface is covered by water?</strong></p>
                                                    <div class="btn-group-vertical w-100">
                                                        <button class="btn btn-outline-primary quiz-option" data-answer="false" onclick="answerQuiz(this)">50%</button>
                                                        <button class="btn btn-outline-primary quiz-option" data-answer="true" onclick="answerQuiz(this)">71%</button>
                                                        <button class="btn btn-outline-primary quiz-option" data-answer="false" onclick="answerQuiz(this)">85%</button>
                                                        <button class="btn btn-outline-primary quiz-option" data-answer="false" onclick="answerQuiz(this)">90%</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-3">
                                            <div class="progress-eco">
                                                <div class="progress-bar" id="quizProgress" style="width: 0%"></div>
                                            </div>
                                            <small class="text-muted">Progress: <span id="quizScore">0</span>%</small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <!-- Complete Mission Button -->
                                <div class="mt-4">
                                    <button id="completeMissionBtn" class="btn btn-success btn-lg" onclick="completeMission()" disabled>
                                        <i class="fas fa-check me-2"></i>Complete Mission
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mission Completion Form -->
    <form id="completionForm" method="POST" style="display: none;">
        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
        <input type="hidden" name="complete_mission" value="1">
        <input type="hidden" name="score" id="finalScore" value="100">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let gameScore = 0;
        let gameProgress = 0;
        let treesPlanted = 0;
        let itemsSorted = 0;
        let quizAnswered = false;

        // Tree Planting Game
        function plantTree(spot) {
            if (!spot.classList.contains('planted')) {
                spot.innerHTML = '<i class="fas fa-tree text-success fa-2x"></i>';
                spot.classList.add('planted');
                treesPlanted++;
                
                document.getElementById('treesPlanted').textContent = treesPlanted;
                const progress = (treesPlanted / 12) * 100;
                document.getElementById('treeProgress').style.width = progress + '%';
                
                if (treesPlanted >= 12) {
                    gameScore = 100;
                    document.getElementById('completeMissionBtn').disabled = false;
                    showSuccessMessage('Forest restored! Great job planting all the trees!');
                }
            }
        }

        // Waste Sorting Game
        function sortWaste(item, type) {
            if (!item.classList.contains('sorted')) {
                item.classList.add('sorted');
                item.style.opacity = '0.5';
                itemsSorted++;
                
                document.getElementById('itemsSorted').textContent = itemsSorted;
                const progress = (itemsSorted / 4) * 100;
                document.getElementById('wasteProgress').style.width = progress + '%';
                
                if (itemsSorted >= 4) {
                    gameScore = 100;
                    document.getElementById('completeMissionBtn').disabled = false;
                    showSuccessMessage('All waste sorted correctly! You\'re helping reduce pollution!');
                }
            }
        }

        // Quiz Game
        function answerQuiz(button) {
            if (!quizAnswered) {
                quizAnswered = true;
                const isCorrect = button.dataset.answer === 'true';
                
                document.querySelectorAll('.quiz-option').forEach(btn => {
                    btn.disabled = true;
                    if (btn.dataset.answer === 'true') {
                        btn.classList.add('btn-success');
                        btn.classList.remove('btn-outline-primary');
                    } else if (btn === button && !isCorrect) {
                        btn.classList.add('btn-danger');
                        btn.classList.remove('btn-outline-primary');
                    }
                });
                
                gameScore = isCorrect ? 100 : 75;
                document.getElementById('quizProgress').style.width = '100%';
                document.getElementById('quizScore').textContent = gameScore;
                document.getElementById('completeMissionBtn').disabled = false;
                
                if (isCorrect) {
                    showSuccessMessage('Correct! You know your environmental facts!');
                } else {
                    showSuccessMessage('Good try! The correct answer is 71%. Keep learning!');
                }
            }
        }

        // Complete Mission
        function completeMission() {
            document.getElementById('finalScore').value = gameScore;
            document.getElementById('completionForm').submit();
        }

        // Show success message
        function showSuccessMessage(message) {
            const alert = document.createElement('div');
            alert.className = 'alert alert-success alert-dismissible fade show mt-3';
            alert.innerHTML = `
                <i class="fas fa-check-circle me-2"></i>${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            document.getElementById('gameArea').appendChild(alert);
        }

        // Add CSS for game elements
        const style = document.createElement('style');
        style.textContent = `
            .tree-spot, .waste-item, .bin {
                cursor: pointer;
                padding: 1rem;
                border: 2px dashed #dee2e6;
                border-radius: 10px;
                transition: all 0.3s ease;
                margin-bottom: 1rem;
            }
            
            .tree-spot:hover, .waste-item:hover, .bin:hover {
                border-color: #28a745;
                background-color: #f8f9fa;
            }
            
            .tree-spot.planted {
                border-color: #28a745;
                background-color: #d4edda;
            }
            
            .waste-item.sorted {
                border-color: #28a745;
                background-color: #d4edda;
            }
            
            .quiz-option {
                margin-bottom: 0.5rem;
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>

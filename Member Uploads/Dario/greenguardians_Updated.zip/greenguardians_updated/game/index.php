<?php
require_once '../config/config.php';
require_once '../classes/User.php';
require_once '../classes/Mission.php';

// Check if user is logged in
if(!isLoggedIn()) {
    redirect('../auth/login.php');
}

$database = new Database();
$db = $database->getConnection();

$user = new User($db);
$mission = new Mission($db);

// Get current user data
$user->getUserById($_SESSION['user_id']);

// Get user missions
$user_missions = $mission->getUserMissions($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Missions - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-eco navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../">
                <i class="fas fa-leaf" style="font-size: 2.5rem;"></i>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../dashboard/">
                            <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">
                            <i class="fas fa-gamepad me-1"></i>Missions
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../leaderboard/">
                            <i class="fas fa-trophy me-1"></i>Leaderboard
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($user->username); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../profile/"><i class="fas fa-user-edit me-2"></i>Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Header -->
    <div class="dashboard-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-2"><i class="fas fa-gamepad me-2"></i>Environmental Missions</h1>
                    <p class="mb-0 opacity-75">Choose your mission and help save the planet!</p>
                </div>
                <div class="col-md-4 text-md-end">
                    <div class="text-white">
                        <i class="fas fa-coins me-1"></i><?php echo number_format($user->eco_points); ?> Eco-Points
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-4">
        <!-- Mission Categories -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="eco-card p-4">
                    <h4 class="mb-3"><i class="fas fa-filter me-2 text-success"></i>Filter by Difficulty</h4>
                    <div class="btn-group" role="group">
                        <input type="radio" class="btn-check" name="difficulty" id="all" value="all" checked>
                        <label class="btn btn-outline-success" for="all">All Missions</label>

                        <input type="radio" class="btn-check" name="difficulty" id="easy" value="easy">
                        <label class="btn btn-outline-success" for="easy">Easy</label>

                        <input type="radio" class="btn-check" name="difficulty" id="medium" value="medium">
                        <label class="btn btn-outline-warning" for="medium">Medium</label>

                        <input type="radio" class="btn-check" name="difficulty" id="hard" value="hard">
                        <label class="btn btn-outline-danger" for="hard">Hard</label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Missions Grid -->
        <div class="row g-4" id="missions-container">
            <?php foreach($user_missions as $mission): 
                $status = $mission['status'] ?? 'not-started';
                $progress = $mission->getMissionProgress($_SESSION['user_id'], $mission['id']);
            ?>
            <div class="col-lg-4 col-md-6 mission-item" data-difficulty="<?php echo $mission['difficulty']; ?>">
                <div class="eco-card mission-card difficulty-<?php echo $mission['difficulty']; ?> h-100">
                    <div class="card-body p-4">
                        <!-- Mission Status Badge -->
                        <div class="mission-status status-<?php echo $status; ?>">
                            <?php 
                            switch($status) {
                                case 'completed':
                                    echo '<i class="fas fa-check me-1"></i>Completed';
                                    break;
                                case 'in_progress':
                                    echo '<i class="fas fa-play me-1"></i>In Progress';
                                    break;
                                default:
                                    echo '<i class="fas fa-lock me-1"></i>Not Started';
                            }
                            ?>
                        </div>

                        <!-- SDG Badge -->
                        <div class="mb-3">
                            <span class="sdg-badge"><?php echo htmlspecialchars($mission['sdg_goal']); ?></span>
                            <span class="badge bg-<?php echo $mission['difficulty'] == 'easy' ? 'success' : ($mission['difficulty'] == 'medium' ? 'warning' : 'danger'); ?> ms-2">
                                <?php echo ucfirst($mission['difficulty']); ?>
                            </span>
                        </div>

                        <!-- Mission Content -->
                        <h5 class="card-title"><?php echo htmlspecialchars($mission['title']); ?></h5>
                        <p class="card-text text-muted"><?php echo htmlspecialchars($mission['description']); ?></p>

                        <!-- Progress Bar (if in progress) -->
                        <?php if($status === 'in_progress'): ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <small>Progress</small>
                                <small><?php echo $mission['score'] ?? 0; ?>%</small>
                            </div>
                            <div class="progress-eco">
                                <div class="progress-bar" style="width: <?php echo $mission['score'] ?? 0; ?>%"></div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Eco Fact Preview -->
                        <?php if($mission['eco_fact']): ?>
                        <div class="eco-fact mb-3">
                            <small><strong>Eco-Fact:</strong> <?php echo htmlspecialchars(substr($mission['eco_fact'], 0, 100)) . '...'; ?></small>
                        </div>
                        <?php endif; ?>

                        <!-- Action Buttons -->
                        <div class="d-flex justify-content-between align-items-center mt-auto">
                            <span class="text-success fw-bold">
                                <i class="fas fa-coins me-1"></i><?php echo $mission['points_reward']; ?> Points
                            </span>
                            
                            <?php if($status === 'completed'): ?>
                                <div class="d-flex align-items-center">
                                    <span class="badge bg-success me-2">
                                        <i class="fas fa-star me-1"></i><?php echo $mission['score']; ?>%
                                    </span>
                                    <button class="btn btn-outline-success btn-sm" onclick="showMissionDetails(<?php echo $mission['id']; ?>)">
                                        <i class="fas fa-info me-1"></i>Details
                                    </button>
                                </div>
                            <?php elseif($status === 'in_progress'): ?>
                                <a href="mission.php?id=<?php echo $mission['id']; ?>" class="btn btn-warning">
                                    <i class="fas fa-play me-1"></i>Continue
                                </a>
                            <?php else: ?>
                                <a href="mission.php?id=<?php echo $mission['id']; ?>" class="btn btn-success">
                                    <i class="fas fa-rocket me-1"></i>Start Mission
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Empty State -->
        <div id="no-missions" class="text-center py-5" style="display: none;">
            <i class="fas fa-search fa-3x text-muted mb-3"></i>
            <h5>No missions found</h5>
            <p class="text-muted">Try adjusting your filter settings.</p>
        </div>
    </div>

    <!-- Mission Details Modal -->
    <div class="modal fade" id="missionModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Mission Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="missionModalBody">
                    <!-- Content loaded via JavaScript -->
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Mission filtering
        document.querySelectorAll('input[name="difficulty"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const selectedDifficulty = this.value;
                const missions = document.querySelectorAll('.mission-item');
                let visibleCount = 0;

                missions.forEach(mission => {
                    if (selectedDifficulty === 'all' || mission.dataset.difficulty === selectedDifficulty) {
                        mission.style.display = 'block';
                        visibleCount++;
                    } else {
                        mission.style.display = 'none';
                    }
                });

                // Show/hide empty state
                document.getElementById('no-missions').style.display = visibleCount === 0 ? 'block' : 'none';
            });
        });

        // Mission details modal
        function showMissionDetails(missionId) {
            // You can implement AJAX call here to fetch mission details
            const modal = new bootstrap.Modal(document.getElementById('missionModal'));
            document.getElementById('missionModalBody').innerHTML = `
                <div class="text-center">
                    <div class="eco-spinner mb-3"></div>
                    <p>Loading mission details...</p>
                </div>
            `;
            modal.show();
            
            // Simulate loading (replace with actual AJAX call)
            setTimeout(() => {
                document.getElementById('missionModalBody').innerHTML = `
                    <div class="text-center">
                        <i class="fas fa-check-circle text-success fa-3x mb-3"></i>
                        <h4>Mission Completed!</h4>
                        <p class="text-muted">Great job on completing this environmental mission!</p>
                        <div class="eco-fact">
                            <strong>What you learned:</strong> Environmental facts and sustainable practices that make a real difference.
                        </div>
                    </div>
                `;
            }, 1500);
        }

        // Add animation to cards
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.mission-card');
            cards.forEach((card, index) => {
                card.style.animationDelay = `${index * 0.1}s`;
                card.classList.add('fade-in-up');
            });
        });
    </script>
</body>
</html>

<?php
require_once '../config/config.php';
require_once '../classes/User.php';
require_once '../classes/Mission.php';
require_once '../classes/Achievement.php';

// Check if user is logged in and is admin
if(!isLoggedIn() || !isAdmin()) {
    redirect('../auth/login.php');
}

$database = new Database();
$db = $database->getConnection();

$user = new User($db);
$mission = new Mission($db);
$achievement = new Achievement($db);

// Get admin stats
$all_missions = $mission->getAllMissions();
$all_achievements = $achievement->getAllAchievements();
$leaderboard = $user->getLeaderboard(10);

// Handle actions
$success_message = '';
$error_message = '';

if($_POST) {
    if(!verifyCSRFToken($_POST['csrf_token'])) {
        $error_message = "Invalid request. Please try again.";
    } else {
        // Handle mission creation
        if(isset($_POST['create_mission'])) {
            $mission->title = $_POST['title'];
            $mission->description = $_POST['description'];
            $mission->difficulty = $_POST['difficulty'];
            $mission->points_reward = (int)$_POST['points_reward'];
            $mission->sdg_goal = $_POST['sdg_goal'];
            $mission->eco_fact = $_POST['eco_fact'];
            
            if($mission->createMission()) {
                $success_message = "Mission created successfully!";
            } else {
                $error_message = "Failed to create mission.";
            }
        }
        
        // Handle achievement creation
        if(isset($_POST['create_achievement'])) {
            $achievement->name = $_POST['name'];
            $achievement->description = $_POST['description'];
            $achievement->badge_icon = $_POST['badge_icon'];
            $achievement->points_required = (int)$_POST['points_required'];
            $achievement->missions_required = (int)$_POST['missions_required'];
            
            if($achievement->createAchievement()) {
                $success_message = "Achievement created successfully!";
            } else {
                $error_message = "Failed to create achievement.";
            }
        }
    }
}

// Get current user data
$current_user = new User($db);
$current_user->getUserById($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-eco navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../">
                <i class="fas fa-leaf me-2"></i><?php echo SITE_NAME; ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../dashboard/">
                            <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">
                            <i class="fas fa-cog me-1"></i>Admin Panel
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($current_user->username); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../profile/"><i class="fas fa-user-edit me-2"></i>Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Header -->
    <div class="dashboard-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-2"><i class="fas fa-cog me-2"></i>Admin Panel</h1>
                    <p class="mb-0 opacity-75">Manage missions, achievements, and system content</p>
                </div>
                <div class="col-md-4 text-md-end">
                    <div class="text-white">
                        <i class="fas fa-shield-alt me-1"></i>Administrator Access
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-4">
        <!-- Alerts -->
        <?php if($success_message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if($error_message): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Stats Overview -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-tasks text-success" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-success mb-0"><?php echo count($all_missions); ?></h3>
                    <small class="text-muted">Total Missions</small>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-trophy text-warning" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-warning mb-0"><?php echo count($all_achievements); ?></h3>
                    <small class="text-muted">Total Achievements</small>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-users text-info" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-info mb-0"><?php echo count($leaderboard); ?></h3>
                    <small class="text-muted">Active Users</small>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-coins text-primary" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-primary mb-0"><?php echo !empty($leaderboard) ? number_format($leaderboard[0]['eco_points']) : '0'; ?></h3>
                    <small class="text-muted">Highest Score</small>
                </div>
            </div>
        </div>

        <!-- Admin Tabs -->
        <div class="eco-card p-4">
            <ul class="nav nav-tabs" id="adminTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="missions-tab" data-bs-toggle="tab" data-bs-target="#missions" type="button" role="tab">
                        <i class="fas fa-tasks me-2"></i>Missions
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="achievements-tab" data-bs-toggle="tab" data-bs-target="#achievements" type="button" role="tab">
                        <i class="fas fa-trophy me-2"></i>Achievements
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="users-tab" data-bs-toggle="tab" data-bs-target="#users" type="button" role="tab">
                        <i class="fas fa-users me-2"></i>Users
                    </button>
                </li>
            </ul>

            <div class="tab-content mt-4" id="adminTabsContent">
                <!-- Missions Tab -->
                <div class="tab-pane fade show active" id="missions" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4>Manage Missions</h4>
                        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createMissionModal">
                            <i class="fas fa-plus me-2"></i>Create Mission
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Difficulty</th>
                                    <th>Points</th>
                                    <th>SDG Goal</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($all_missions as $mission_item): ?>
                                <tr>
                                    <td><?php echo $mission_item['id']; ?></td>
                                    <td><?php echo htmlspecialchars($mission_item['title']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $mission_item['difficulty'] == 'easy' ? 'success' : ($mission_item['difficulty'] == 'medium' ? 'warning' : 'danger'); ?>">
                                            <?php echo ucfirst($mission_item['difficulty']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $mission_item['points_reward']; ?></td>
                                    <td><small><?php echo htmlspecialchars($mission_item['sdg_goal']); ?></small></td>
                                    <td>
                                        <span class="badge bg-<?php echo $mission_item['is_active'] ? 'success' : 'secondary'; ?>">
                                            <?php echo $mission_item['is_active'] ? 'Active' : 'Inactive'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary" onclick="editMission(<?php echo $mission_item['id']; ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteMission(<?php echo $mission_item['id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Achievements Tab -->
                <div class="tab-pane fade" id="achievements" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4>Manage Achievements</h4>
                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#createAchievementModal">
                            <i class="fas fa-plus me-2"></i>Create Achievement
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Points Required</th>
                                    <th>Missions Required</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($all_achievements as $achievement_item): ?>
                                <tr>
                                    <td><?php echo $achievement_item['id']; ?></td>
                                    <td><?php echo htmlspecialchars($achievement_item['name']); ?></td>
                                    <td><?php echo $achievement_item['points_required']; ?></td>
                                    <td><?php echo $achievement_item['missions_required']; ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $achievement_item['is_active'] ? 'success' : 'secondary'; ?>">
                                            <?php echo $achievement_item['is_active'] ? 'Active' : 'Inactive'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary" onclick="editAchievement(<?php echo $achievement_item['id']; ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteAchievement(<?php echo $achievement_item['id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Users Tab -->
                <div class="tab-pane fade" id="users" role="tabpanel">
                    <h4 class="mb-4">User Management</h4>
                    
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Rank</th>
                                    <th>Username</th>
                                    <th>Eco-Points</th>
                                    <th>Eco-Rank</th>
                                    <th>Joined</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($leaderboard as $index => $leader): ?>
                                <tr>
                                    <td>#<?php echo $index + 1; ?></td>
                                    <td><?php echo htmlspecialchars($leader['username']); ?></td>
                                    <td><?php echo number_format($leader['eco_points']); ?></td>
                                    <td>
                                        <span class="eco-rank rank-<?php echo strtolower(str_replace([' ', '-'], '-', $leader['eco_rank'])); ?>">
                                            <?php echo $leader['eco_rank']; ?>
                                        </span>
                                    </td>
                                    <td><small class="text-muted">Recently</small></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Mission Modal -->
    <div class="modal fade" id="createMissionModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Mission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <input type="hidden" name="create_mission" value="1">
                        
                        <div class="mb-3">
                            <label for="title" class="form-label">Mission Title</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="difficulty" class="form-label">Difficulty</label>
                                    <select class="form-select" id="difficulty" name="difficulty" required>
                                        <option value="easy">Easy</option>
                                        <option value="medium">Medium</option>
                                        <option value="hard">Hard</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="points_reward" class="form-label">Points Reward</label>
                                    <input type="number" class="form-control" id="points_reward" name="points_reward" min="50" max="500" value="100" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="sdg_goal" class="form-label">SDG Goal</label>
                            <select class="form-select" id="sdg_goal" name="sdg_goal" required>
                                <option value="SDG 6: Clean Water">SDG 6: Clean Water</option>
                                <option value="SDG 7: Affordable Clean Energy">SDG 7: Affordable Clean Energy</option>
                                <option value="SDG 12: Responsible Consumption">SDG 12: Responsible Consumption</option>
                                <option value="SDG 13: Climate Action">SDG 13: Climate Action</option>
                                <option value="SDG 15: Life on Land">SDG 15: Life on Land</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="eco_fact" class="form-label">Eco-Fact</label>
                            <textarea class="form-control" id="eco_fact" name="eco_fact" rows="2" placeholder="Educational fact related to this mission"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Create Mission</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Create Achievement Modal -->
    <div class="modal fade" id="createAchievementModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Achievement</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <input type="hidden" name="create_achievement" value="1">
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Achievement Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="achievement_description" class="form-label">Description</label>
                            <textarea class="form-control" id="achievement_description" name="description" rows="2" required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="badge_icon" class="form-label">Badge Icon</label>
                            <input type="text" class="form-control" id="badge_icon" name="badge_icon" placeholder="e.g., medal.png" value="medal.png">
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="points_required" class="form-label">Points Required</label>
                                    <input type="number" class="form-control" id="points_required" name="points_required" min="0" value="0">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="missions_required" class="form-label">Missions Required</label>
                                    <input type="number" class="form-control" id="missions_required" name="missions_required" min="0" value="0">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning">Create Achievement</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        function editMission(id) {
            alert('Edit mission functionality would be implemented here for mission ID: ' + id);
        }

        function deleteMission(id) {
            if (confirm('Are you sure you want to delete this mission?')) {
                alert('Delete mission functionality would be implemented here for mission ID: ' + id);
            }
        }

        function editAchievement(id) {
            alert('Edit achievement functionality would be implemented here for achievement ID: ' + id);
        }

        function deleteAchievement(id) {
            if (confirm('Are you sure you want to delete this achievement?')) {
                alert('Delete achievement functionality would be implemented here for achievement ID: ' + id);
            }
        }
    </script>
</body>
</html>

<?php
// Database Setup Script for GreenGuardians
echo "<h2>GreenGuardians Database Setup</h2>";

// Database connection settings
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'greenguardians';

try {
    // Connect to MySQL server (without database)
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database if it doesn't exist
    $pdo->exec("CREATE DATABASE IF NOT EXISTS $database");
    echo "<p style='color: green;'>✓ Database '$database' created successfully!</p>";
    
    // Connect to the specific database
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Read and execute the schema file
    $schema = file_get_contents(__DIR__ . '/database/schema.sql');
    
    // Split the schema into individual queries
    $queries = explode(';', $schema);
    
    foreach($queries as $query) {
        $query = trim($query);
        if(!empty($query)) {
            $pdo->exec($query);
        }
    }
    
    echo "<p style='color: green;'>✓ Database tables created successfully!</p>";
    echo "<p style='color: green;'>✓ Sample data inserted successfully!</p>";
    echo "<p style='color: blue;'>🎉 Setup complete! You can now use GreenGuardians.</p>";
    echo "<p><strong>Default Admin Account:</strong></p>";
    echo "<ul>";
    echo "<li>Username: <code>admin</code></li>";
    echo "<li>Password: <code>admin123</code></li>";
    echo "</ul>";
    echo "<p><a href='index.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to GreenGuardians</a></p>";
    
} catch(PDOException $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>Please make sure:</p>";
    echo "<ul>";
    echo "<li>XAMPP is running</li>";
    echo "<li>MySQL service is started</li>";
    echo "<li>Database credentials are correct</li>";
    echo "</ul>";
}
?>

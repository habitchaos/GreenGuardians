<?php
require_once __DIR__ . '/config/config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meet the Developers - <?php echo SITE_NAME; ?></title>
    <meta name="description" content="Meet the talented team behind GreenGuardians - passionate developers committed to environmental education through technology.">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-eco navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-leaf" style="font-size: 2.5rem;"></i>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="index.php#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white active" href="developers.php">Developers</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <?php if(isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="btn btn-outline-light me-2" href="dashboard/">
                                <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-light" href="auth/logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Logout
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-outline-light me-2" href="auth/login.php">
                                <i class="fas fa-sign-in-alt me-1"></i>Sign In
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-light" href="auth/register.php">
                                <i class="fas fa-user-plus me-1"></i>Sign Up
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <main>
    <!-- Hero Section -->
    <section class="hero-section" style="padding: 100px 0 60px 0; margin-top: 80px;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h1 class="hero-title">Meet the Developers</h1>
                    <p class="hero-subtitle">Built with passion for our planet</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Developer Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <!-- Developer Slider -->
            <div class="developer-slider-container position-relative">
                <div class="developer-slider" id="developerSlider">
                    <!-- Developer 1 -->
                    <div class="developer-slide active">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="eco-card p-5 text-center">
                                    <div class="mb-4">
                                        <div class="developer-avatar mx-auto mb-3">
                                            <img src="assets/img/developers/el-francis.jpg" alt="El Francis B. Dela Cruz" class="developer-profile-img">
                                        </div>
                                        <h3 class="text-success mb-2">El Francis B. Dela Cruz</h3>
                                        <p class="text-muted mb-4">Lead Full-Stack Developer & Project Architect</p>
                                    </div>
                                    
                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <h5 class="text-success mb-3">Specializations</h5>
                                            <div class="d-flex flex-wrap">
                                                <span class="badge bg-primary me-2 mb-2">PHP</span>
                                                <span class="badge bg-info me-2 mb-2">MySQL</span>
                                                <span class="badge bg-success me-2 mb-2">Backend Architecture</span>
                                                <span class="badge bg-warning me-2 mb-2">API Development</span>
                                                <span class="badge bg-danger me-2 mb-2">HTML5</span>
                                                <span class="badge bg-primary me-2 mb-2">CSS3</span>
                                                <span class="badge bg-success me-2 mb-2">Bootstrap 5</span>
                                                <span class="badge bg-warning me-2 mb-2">UI Design</span>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <h5 class="text-success mb-3">Contributions</h5>
                                            <ul class="list-unstyled text-start">
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Database Design</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>User Authentication</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Mission System</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Admin Panel</li>
                                            </ul>
                                        </div>
                                    </div>
                                    
                                    <div class="developer-message p-4 bg-light rounded">
                                        <h5 class="text-success mb-3">Developer's Message</h5>
                                        <p class="mb-0 text-muted"><em>"Leading the backend development, I focused on creating a robust and scalable system that can handle the gamification elements while maintaining security and performance."</em></p>
                                    </div>
                                    
                                    <!-- Social Links -->
                                    <div class="social-links mt-4 text-start">
                                        <h6 class="text-success mb-3">Connect with El Francis</h6>
                                        <div class="d-flex gap-3">
                                            <a href="https://web.facebook.com/elfrancisreal" target="_blank" class="social-link facebook" title="Facebook">
                                                <i class="fab fa-facebook-f"></i>
                                            </a>
                                            <a href="https://instagram.com/elfr0022" target="_blank" class="social-link instagram" title="Instagram">
                                                <i class="fab fa-instagram"></i>
                                            </a>
                                            <a href="https://github.com/habitchaos" target="_blank" class="social-link github" title="GitHub">
                                                <i class="fab fa-github"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Developer 2 -->
                    <div class="developer-slide">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="eco-card p-5 text-center">
                                    <div class="mb-4">
                                        <div class="developer-avatar mx-auto mb-3">
                                            <img src="assets/img/developers/dario-agliam.jpg" alt="Dario E. Agliam Jr" class="developer-profile-img">
                                        </div>
                                        <h3 class="text-success mb-2">Dario E. Agliam Jr</h3>
                                        <p class="text-muted mb-4">UI/UX Designer & Frontend Developer</p>
                                    </div>
                                    
                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <h5 class="text-success mb-3">Specializations</h5>
                                            <div class="d-flex flex-wrap">
                                                <span class="badge bg-danger me-2 mb-2">HTML5</span>
                                                <span class="badge bg-primary me-2 mb-2">CSS3</span>
                                                <span class="badge bg-success me-2 mb-2">Bootstrap 5</span>
                                                <span class="badge bg-warning me-2 mb-2">UI Design</span>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <h5 class="text-success mb-3">Contributions</h5>
                                            <ul class="list-unstyled text-start">
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Responsive Design</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>User Interface</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Visual Branding</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>User Experience</li>
                                            </ul>
                                        </div>
                                    </div>
                                    
                                    <div class="developer-message p-4 bg-light rounded">
                                        <h5 class="text-success mb-3">Developer's Message</h5>
                                        <p class="mb-0 text-muted"><em>"I designed GreenGuardians with an eco-friendly aesthetic that makes environmental education feel approachable and engaging for users of all ages."</em></p>
                                    </div>
                                    
                                    <!-- Social Links -->
                                    <div class="social-links mt-4 text-start">
                                        <h6 class="text-success mb-3">Connect with Dario</h6>
                                        <div class="d-flex gap-3">
                                            <a href="https://web.facebook.com/darioedaleagliamjr" target="_blank" class="social-link facebook" title="Facebook">
                                                <i class="fab fa-facebook-f"></i>
                                            </a>
                                            <a href="https://instagram.com/darriusthegreat1" target="_blank" class="social-link instagram" title="Instagram">
                                                <i class="fab fa-instagram"></i>
                                            </a>
                                            <a href="https://github.com/eMWJASUGAKS7576i" target="_blank" class="social-link github" title="GitHub">
                                                <i class="fab fa-github"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Developer 3 -->
                    <div class="developer-slide">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="eco-card p-5 text-center">
                                    <div class="mb-4">
                                        <div class="developer-avatar mx-auto mb-3">
                                            <img src="assets/img/developers/eldrick-castelo.jpg" alt="Eldrick Gilmer G. Castelo" class="developer-profile-img">
                                        </div>
                                        <h3 class="text-success mb-2">Eldrick Gilmer G. Castelo</h3>
                                        <p class="text-muted mb-4">Game Developer & JavaScript Specialist</p>
                                    </div>
                                    
                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <h5 class="text-success mb-3">Specializations</h5>
                                            <div class="d-flex flex-wrap">
                                                <span class="badge bg-warning me-2 mb-2">JavaScript</span>
                                                <span class="badge bg-info me-2 mb-2">Game Logic</span>
                                                <span class="badge bg-success me-2 mb-2">Animations</span>
                                                <span class="badge bg-primary me-2 mb-2">Interactivity</span>
                                                <span class="badge bg-danger me-2 mb-2">HTML5</span>
                                                <span class="badge bg-primary me-2 mb-2">CSS3</span>
                                                <span class="badge bg-success me-2 mb-2">Bootstrap 5</span>
                                                <span class="badge bg-warning me-2 mb-2">UI Design</span>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <h5 class="text-success mb-3">Contributions</h5>
                                            <ul class="list-unstyled text-start">
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Interactive Games</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Mission Mechanics</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Animations</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>User Interactions</li>
                                            </ul>
                                        </div>
                                    </div>
                                    
                                    <div class="developer-message p-4 bg-light rounded">
                                        <h5 class="text-success mb-3">Developer's Message</h5>
                                        <p class="mb-0 text-muted"><em>"Creating the interactive elements was exciting! I wanted to make environmental learning feel like playing a game, not studying a textbook."</em></p>
                                    </div>
                                    
                                    <!-- Social Links -->
                                    <div class="social-links mt-4 text-start">
                                        <h6 class="text-success mb-3">Connect with Eldrick</h6>
                                        <div class="d-flex gap-3">
                                            <a href="https://facebook.com/eldrick.gilmer.gutierrez.castelo" target="_blank" class="social-link facebook" title="Facebook">
                                                <i class="fab fa-facebook-f"></i>
                                            </a>
                                            <a href="https://instagram.com/eldrick_gilmer" target="_blank" class="social-link instagram" title="Instagram">
                                                <i class="fab fa-instagram"></i>
                                            </a>
                                            <a href="https://github.com/Gilmer13" target="_blank" class="social-link github" title="GitHub">
                                                <i class="fab fa-github"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Developer 4 -->
                    <div class="developer-slide">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="eco-card p-5 text-center">
                                    <div class="mb-4">
                                        <div class="developer-avatar mx-auto mb-3">
                                            <img src="assets/img/developers/mcgregor-moises.jpg" alt="Mc Gregor S. Moises" class="developer-profile-img">
                                        </div>
                                        <h3 class="text-success mb-2">Mc Gregor S. Moises</h3>
                                        <p class="text-muted mb-4">Environmental Consultant & Content Specialist</p>
                                    </div>
                                    
                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <h5 class="text-success mb-3">Specializations</h5>
                                            <div class="d-flex flex-wrap">
                                                <span class="badge bg-success me-2 mb-2">Environmental Science</span>
                                                <span class="badge bg-info me-2 mb-2">SDG Research</span>
                                                <span class="badge bg-primary me-2 mb-2">Content Creation</span>
                                                <span class="badge bg-warning me-2 mb-2">Education</span>
                                                <span class="badge bg-danger me-2 mb-2">HTML5</span>
                                                <span class="badge bg-primary me-2 mb-2">CSS3</span>
                                                <span class="badge bg-success me-2 mb-2">Bootstrap 5</span>
                                                <span class="badge bg-warning me-2 mb-2">UI Design</span>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <h5 class="text-success mb-3">Contributions</h5>
                                            <ul class="list-unstyled text-start">
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Educational Content</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Eco-Facts Research</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>SDG Alignment</li>
                                                <li class="mb-1"><i class="fas fa-check text-success me-2"></i>Mission Design</li>
                                            </ul>
                                        </div>
                                    </div>
                                    
                                    <div class="developer-message p-4 bg-light rounded">
                                        <h5 class="text-success mb-3">Developer's Message</h5>
                                        <p class="mb-0 text-muted"><em>"As an environmental scientist, I ensured all content is scientifically accurate and aligned with UN SDGs. Education is key to environmental action!"</em></p>
                                    </div>
                                    
                                    <!-- Social Links -->
                                    <div class="social-links mt-4 text-start">
                                        <h6 class="text-success mb-3">Connect with Mc Gregor</h6>
                                        <div class="d-flex gap-3">
                                            <a href="https://facebook.com/61578696575863" target="_blank" class="social-link facebook" title="Facebook">
                                                <i class="fab fa-facebook-f"></i>
                                            </a>
                                            <a href="https://instagram.com/ouisaki" target="_blank" class="social-link instagram" title="Instagram">
                                                <i class="fab fa-instagram"></i>
                                            </a>
                                            <a href="https://github.com/tmsaki30" target="_blank" class="social-link github" title="GitHub">
                                                <i class="fab fa-github"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Navigation Buttons -->
                <button class="slider-btn slider-btn-prev" onclick="prevDeveloper()">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="slider-btn slider-btn-next" onclick="nextDeveloper()">
                    <i class="fas fa-chevron-right"></i>
                </button>

                <!-- Dots Indicator -->
                <div class="slider-dots text-center mt-4">
                    <span class="dot active" onclick="currentDeveloper(1)"></span>
                    <span class="dot" onclick="currentDeveloper(2)"></span>
                    <span class="dot" onclick="currentDeveloper(3)"></span>
                    <span class="dot" onclick="currentDeveloper(4)"></span>
                </div>
            </div>

        </div>
    </section>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><i class="fas fa-leaf me-2"></i><?php echo SITE_NAME; ?></h5>
                    <p class="text-muted">Gamifying environmental action for a sustainable future.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="text-muted mb-1">
                        Supporting UN SDG 13 (Climate Action) & SDG 15 (Life on Land)
                    </p>
                    <p class="text-muted mb-1">
                        &copy; <?php echo date('Y'); ?> GreenGuardians. Built with 💚 for our planet.
                    </p>
                    <small class="text-muted">
                        Developed by GreenGuardians Team | Making environmental education engaging
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>

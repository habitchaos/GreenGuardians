<?php
require_once '../config/config.php';
require_once '../classes/User.php';
require_once '../classes/Mission.php';
require_once '../classes/Achievement.php';

// Check if user is logged in
if(!isLoggedIn()) {
    redirect('../auth/login.php');
}

$database = new Database();
$db = $database->getConnection();

$user = new User($db);
$mission = new Mission($db);
$achievement = new Achievement($db);

// Get current user data
$user->getUserById($_SESSION['user_id']);

// Get user missions and stats
$user_missions = $mission->getUserMissions($_SESSION['user_id']);
$mission_stats = $mission->getUserMissionStats($_SESSION['user_id']);
$user_achievements = $achievement->getUserAchievements($_SESSION['user_id']);
$achievement_progress = $achievement->getAchievementProgress($_SESSION['user_id']);

// Get leaderboard position
$leaderboard = $user->getLeaderboard(100);
$user_position = 0;
foreach($leaderboard as $index => $leader) {
    if($leader['username'] === $user->username) {
        $user_position = $index + 1;
        break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-eco navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../">
                <i class="fas fa-leaf me-2"></i><?php echo SITE_NAME; ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">
                            <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../game/">
                            <i class="fas fa-gamepad me-1"></i>Play
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../leaderboard/">
                            <i class="fas fa-trophy me-1"></i>Leaderboard
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($user->username); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../profile/"><i class="fas fa-user-edit me-2"></i>Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Dashboard Header -->
    <div class="dashboard-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-2">Welcome back, <?php echo htmlspecialchars($user->username); ?>!</h1>
                    <p class="mb-0 opacity-75">Ready to continue your eco-mission?</p>
                </div>
                <div class="col-md-4 text-md-end">
                    <div class="eco-rank rank-<?php echo strtolower(str_replace([' ', '-'], '-', $user->eco_rank)); ?>">
                        <?php echo $user->eco_rank; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-4">
        <!-- Stats Overview -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-coins text-success" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-success mb-0"><?php echo number_format($user->eco_points); ?></h3>
                    <small class="text-muted">Eco-Points</small>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-tasks text-info" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-info mb-0"><?php echo $mission_stats['completed_missions'] ?? 0; ?></h3>
                    <small class="text-muted">Missions Completed</small>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-trophy text-warning" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-warning mb-0"><?php echo $achievement_progress['earned']; ?></h3>
                    <small class="text-muted">Achievements</small>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="eco-card p-4 text-center">
                    <div class="mb-2">
                        <i class="fas fa-ranking-star text-danger" style="font-size: 2rem;"></i>
                    </div>
                    <h3 class="text-danger mb-0">#<?php echo $user_position ?: '—'; ?></h3>
                    <small class="text-muted">Leaderboard Rank</small>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Missions Section -->
            <div class="col-lg-8">
                <div class="eco-card p-4 mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4><i class="fas fa-tasks me-2 text-success"></i>Your Missions</h4>
                        <a href="../game/" class="btn btn-success btn-sm">
                            <i class="fas fa-plus me-1"></i>Start New Mission
                        </a>
                    </div>
                    
                    <?php if(!empty($user_missions)): ?>
                        <div class="row g-3">
                            <?php foreach(array_slice($user_missions, 0, 6) as $mission): ?>
                            <div class="col-md-6">
                                <div class="mission-card eco-card difficulty-<?php echo $mission['difficulty']; ?> p-3">
                                    <div class="mission-status status-<?php echo $mission['status'] ?? 'not-started'; ?>">
                                        <?php 
                                        $status = $mission['status'] ?? 'not-started';
                                        echo ucfirst(str_replace('_', ' ', $status)); 
                                        ?>
                                    </div>
                                    
                                    <h6 class="mb-2"><?php echo htmlspecialchars($mission['title']); ?></h6>
                                    <p class="text-muted small mb-2"><?php echo htmlspecialchars(substr($mission['description'], 0, 80)) . '...'; ?></p>
                                    
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-success small">
                                            <i class="fas fa-coins me-1"></i><?php echo $mission['points_reward']; ?> pts
                                        </span>
                                        
                                        <?php if($status === 'completed'): ?>
                                            <span class="badge bg-success">
                                                <i class="fas fa-check me-1"></i>Completed
                                            </span>
                                        <?php elseif($status === 'in_progress'): ?>
                                            <a href="../game/mission.php?id=<?php echo $mission['id']; ?>" class="btn btn-warning btn-sm">
                                                <i class="fas fa-play me-1"></i>Continue
                                            </a>
                                        <?php else: ?>
                                            <a href="../game/mission.php?id=<?php echo $mission['id']; ?>" class="btn btn-success btn-sm">
                                                <i class="fas fa-play me-1"></i>Start
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-rocket fa-3x text-muted mb-3"></i>
                            <h5>Ready to start your first mission?</h5>
                            <p class="text-muted">Begin your journey as an Eco-Warrior!</p>
                            <a href="../game/" class="btn btn-success">
                                <i class="fas fa-play me-2"></i>Start First Mission
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Progress Card -->
                <div class="eco-card p-4 mb-4">
                    <h5><i class="fas fa-chart-line me-2 text-info"></i>Your Progress</h5>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <small>Mission Progress</small>
                            <small><?php echo $mission_stats['completed_missions'] ?? 0; ?>/<?php echo count($user_missions); ?></small>
                        </div>
                        <div class="progress-eco">
                            <div class="progress-bar" style="width: <?php echo count($user_missions) > 0 ? round((($mission_stats['completed_missions'] ?? 0) / count($user_missions)) * 100) : 0; ?>%"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <small>Achievement Progress</small>
                            <small><?php echo $achievement_progress['earned']; ?>/<?php echo $achievement_progress['total']; ?></small>
                        </div>
                        <div class="progress-eco">
                            <div class="progress-bar" style="width: <?php echo $achievement_progress['percentage']; ?>%"></div>
                        </div>
                    </div>
                    
                    <?php if($mission_stats['avg_score']): ?>
                    <div class="text-center">
                        <small class="text-muted">Average Score: </small>
                        <strong class="text-success"><?php echo round($mission_stats['avg_score']); ?>%</strong>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Recent Achievements -->
                <div class="eco-card p-4">
                    <h5><i class="fas fa-trophy me-2 text-warning"></i>Recent Achievements</h5>
                    
                    <?php if(!empty($user_achievements)): ?>
                        <?php foreach(array_slice($user_achievements, 0, 3) as $achievement): ?>
                        <div class="d-flex align-items-center mb-3">
                            <div class="achievement-badge me-3">
                                <i class="fas fa-medal"></i>
                            </div>
                            <div>
                                <h6 class="mb-0"><?php echo htmlspecialchars($achievement['name']); ?></h6>
                                <small class="text-muted"><?php echo date('M j, Y', strtotime($achievement['earned_at'])); ?></small>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        
                        <div class="text-center">
                            <a href="../achievements/" class="btn btn-outline-warning btn-sm">
                                <i class="fas fa-trophy me-1"></i>View All
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-3">
                            <i class="fas fa-medal fa-2x text-muted mb-2"></i>
                            <p class="text-muted small mb-0">Complete missions to earn achievements!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html>

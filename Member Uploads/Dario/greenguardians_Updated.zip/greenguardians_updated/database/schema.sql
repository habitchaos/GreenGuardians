-- GreenGuardians Database Schema
CREATE DATABASE IF NOT EXISTS greenguardians;
USE greenguardians;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    eco_points INT DEFAULT 0,
    eco_rank VARCHAR(50) DEFAULT 'Eco-Newbie',
    avatar VARCHAR(100) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Missions table
CREATE TABLE missions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    points_reward INT DEFAULT 100,
    sdg_goal VARCHAR(50),
    eco_fact TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User missions (progress tracking)
CREATE TABLE user_missions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    mission_id INT,
    status ENUM('not_started', 'in_progress', 'completed') DEFAULT 'not_started',
    score INT DEFAULT 0,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (mission_id) REFERENCES missions(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_mission (user_id, mission_id)
);

-- Achievements table
CREATE TABLE achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    badge_icon VARCHAR(100),
    points_required INT DEFAULT 0,
    missions_required INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User achievements
CREATE TABLE user_achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    achievement_id INT,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (achievement_id) REFERENCES achievements(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_achievement (user_id, achievement_id)
);

-- Daily challenges
CREATE TABLE daily_challenges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    points_reward INT DEFAULT 200,
    challenge_date DATE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User daily challenges
CREATE TABLE user_daily_challenges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    challenge_id INT,
    completed BOOLEAN DEFAULT FALSE,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (challenge_id) REFERENCES daily_challenges(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_daily_challenge (user_id, challenge_id)
);

-- Game sessions (for tracking gameplay)
CREATE TABLE game_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    mission_id INT,
    session_data JSON,
    duration INT DEFAULT 0,
    points_earned INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (mission_id) REFERENCES missions(id) ON DELETE CASCADE
);

-- Insert default missions
INSERT INTO missions (title, description, difficulty, points_reward, sdg_goal, eco_fact) VALUES
('Clean River Challenge', 'Help clean a polluted river by removing trash and debris', 'easy', 100, 'SDG 6: Clean Water', 'Did you know? Over 2 billion people lack access to safely managed drinking water at home.'),
('Tree Planting Mission', 'Plant virtual trees to combat deforestation', 'easy', 150, 'SDG 15: Life on Land', 'A single tree can absorb 48 pounds of CO2 per year and produce enough oxygen for two people.'),
('Waste Sorting Game', 'Sort different types of waste into proper recycling categories', 'medium', 200, 'SDG 12: Responsible Consumption', 'Recycling one aluminum can saves enough energy to power a TV for 3 hours.'),
('Renewable Energy Challenge', 'Build a virtual solar farm to reduce carbon emissions', 'hard', 300, 'SDG 7: Affordable Clean Energy', 'Solar energy is the most abundant energy resource on Earth - 173,000 terawatts strike the Earth continuously.'),
('Wildlife Protection', 'Protect endangered species in their natural habitat', 'medium', 250, 'SDG 15: Life on Land', 'We are currently experiencing the sixth mass extinction, with species disappearing 1,000 to 10,000 times faster than natural rates.');

-- Insert default achievements
INSERT INTO achievements (name, description, badge_icon, points_required, missions_required) VALUES
('Eco-Warrior', 'Complete your first mission', 'eco-warrior.png', 0, 1),
('Tree Hugger', 'Plant 10 virtual trees', 'tree-hugger.png', 500, 0),
('Waste Master', 'Complete 5 waste sorting challenges', 'waste-master.png', 0, 5),
('Planet Protector', 'Earn 1000 eco-points', 'planet-protector.png', 1000, 0),
('Green Guardian', 'Complete 10 missions', 'green-guardian.png', 0, 10),
('Climate Champion', 'Earn 2500 eco-points', 'climate-champion.png', 2500, 0);

-- Insert default admin user (password: admin123)
INSERT INTO users (username, email, password, role, eco_points) VALUES
('admin', 'admin@greenguardians.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 0);

-- Insert sample daily challenge
INSERT INTO daily_challenges (title, description, points_reward, challenge_date) VALUES
('Daily Eco-Action', 'Complete any mission today for bonus points!', 200, CURDATE());
